#!/bin/bash
cd "$(dirname "$0")"
CHANNEL_NAME="scd-deviceid"

../bin/configtxgen -profile ModeKafkaOrderer -channelID scd-system-channel -outputBlock ./channel-artifacts/genesis.block
../bin/configtxgen -profile ModeKafkaChannel -outputCreateChannelTx ./channel-artifacts/channel.tx -channelID $CHANNEL_NAME
../bin/configtxgen -profile ModeKafkaChannel -outputAnchorPeersUpdate ./channel-artifacts/04391007anchors.tx -channelID $CHANNEL_NAME -asOrg ISPB04391007

mkdir -p ./Orderer/Orderer1/configtx/
mkdir -p ./Orderer/Orderer2/configtx/
mkdir -p ./Orderer/Orderer3/configtx/
mkdir -p ./Peer/Peer1/configtx/
mkdir -p ./Peer/Peer2/configtx/

cp ./channel-artifacts/* ./Orderer/Orderer1/configtx/
cp ./channel-artifacts/* ./Orderer/Orderer2/configtx/
cp ./channel-artifacts/* ./Orderer/Orderer3/configtx/
cp ./channel-artifacts/* ./Peer/Peer1/configtx/
cp ./channel-artifacts/* ./Peer/Peer2/configtx/
