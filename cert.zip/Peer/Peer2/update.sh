#!/bin/bash

export VERBOSE=false
ARCH=`uname -m`

# Exit on first error, print all commands.
set -ev

peer chaincode install /opt/gopath/src/github.com/hyperledger/fabric/peer/deviceid_1.0.5.signed
peer chaincode upgrade  -n deviceid -v 1.0.5 -c '{"Args":["initLedger"]}'  -C scd-deviceid  -o orderer-svc:7050 --tls --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/Peer/Peer2/msp/orderer/msp/tlscacerts/tlsca.scd.org.br-cert.pem
