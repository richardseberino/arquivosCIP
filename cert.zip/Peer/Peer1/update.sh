#!/bin/bash

export VERBOSE=false
ARCH=`uname -m`

# Exit on first error, print all commands.
set -ev

peer chaincode package -n deviceid -v 1.0.5 -l node -p /opt/gopath/src/github.com/hyperledger/fabric/peer/chaincode -s -S  /opt/gopath/src/github.com/hyperledger/fabric/peer/deviceid_1.0.5.pkg
peer chaincode signpackage  /opt/gopath/src/github.com/hyperledger/fabric/peer/deviceid_1.0.5.pkg /opt/gopath/src/github.com/hyperledger/fabric/peer/deviceid_1.0.5.signed
peer chaincode install /opt/gopath/src/github.com/hyperledger/fabric/peer/deviceid_1.0.5.signed
