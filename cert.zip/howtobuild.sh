#!/bin/bash
cd "$(dirname "$0")"
CHANNEL_NAME="scd-deviceid"

rm -rf crypto-config
rm -rf channel-artifacts
mkdir channel-artifacts
../bin/cryptogen generate --config=./crypto-config.yaml
export FABRIC_CFG_PATH=$PWD

../bin/configtxgen -profile ModeKafkaOrderer -channelID scd-system-channel -outputBlock ./channel-artifacts/genesis.block
../bin/configtxgen -profile ModeKafkaChannel -outputCreateChannelTx ./channel-artifacts/channel.tx -channelID $CHANNEL_NAME
../bin/configtxgen -profile ModeKafkaChannel -outputAnchorPeersUpdate ./channel-artifacts/04391007anchors.tx -channelID $CHANNEL_NAME -asOrg ISPB04391007

## Remove CA files
rm -rf ./CA/*_sk ./CA/*.pem
cp -r ./crypto-config/peerOrganizations/scd.org.br/ca/* ./CA/

## Remove Orderer files
rm -rf ./Orderer/*/configtx/* ./Orderer/*/msp/orderer/* ./Orderer/*/tls/orderer/*

cp ./channel-artifacts/* ./Orderer/Orderer1/configtx/
cp -r ./crypto-config/ordererOrganizations/scd.org.br/orderers/orderer1.scd.org.br/msp ./Orderer/Orderer1/msp/orderer/
cp -r ./crypto-config/ordererOrganizations/scd.org.br/orderers/orderer1.scd.org.br/tls ./Orderer/Orderer1/tls/orderer/

cp ./channel-artifacts/* ./Orderer/Orderer2/configtx/
cp -r ./crypto-config/ordererOrganizations/scd.org.br/orderers/orderer2.scd.org.br/msp ./Orderer/Orderer2/msp/orderer/
cp -r ./crypto-config/ordererOrganizations/scd.org.br/orderers/orderer2.scd.org.br/tls ./Orderer/Orderer2/tls/orderer/

cp ./channel-artifacts/* ./Orderer/Orderer3/configtx/
cp -r ./crypto-config/ordererOrganizations/scd.org.br/orderers/orderer3.scd.org.br/msp ./Orderer/Orderer3/msp/orderer/
cp -r ./crypto-config/ordererOrganizations/scd.org.br/orderers/orderer3.scd.org.br/tls ./Orderer/Orderer3/tls/orderer/

## Remove Peer files
rm -rf ./Peer/*/configtx/* ./Peer/*/msp/orderer/* ./Peer/*/peer/* ./Peer/*/msp/users

cp ./channel-artifacts/* ./Peer/Peer1/configtx/
cp -r ./crypto-config/peerOrganizations/scd.org.br/peers/peer1.scd.org.br/msp ./Peer/Peer1/peer/
cp -r ./crypto-config/peerOrganizations/scd.org.br/peers/peer1.scd.org.br/tls ./Peer/Peer1/peer/
cp -r ./crypto-config/peerOrganizations/scd.org.br/users ./Peer/Peer1/msp/
cp -r ./crypto-config/ordererOrganizations/scd.org.br/orderers/orderer1.scd.org.br/msp ./Peer/Peer1/msp/orderer

cp ./channel-artifacts/* ./Peer/Peer2/configtx/
cp -r ./crypto-config/peerOrganizations/scd.org.br/peers/peer2.scd.org.br/msp ./Peer/Peer2/peer/
cp -r ./crypto-config/peerOrganizations/scd.org.br/peers/peer2.scd.org.br/tls ./Peer/Peer2/peer/
cp -r ./crypto-config/peerOrganizations/scd.org.br/users ./Peer/Peer2/msp/
cp -r ./crypto-config/ordererOrganizations/scd.org.br/orderers/orderer2.scd.org.br/msp ./Peer/Peer2/msp/orderer
