#!/usr/bin/env bash

type=$1
num=$2
password=$3
user="$type$num"
type="$(tr '[:lower:]' '[:upper:]' <<< ${type:0:1})${type:1}s"
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

echo "Type: $type, User: $user, Password: $password"

if [[ ! -d "$DIR/$type/$user.scd.org.br/msp" ]] && [[ ! -d "$DIR/$type/$user.scd.org.br/tls" ]] && ( [[ $type -eq "Peers" ]] || [[ $type -eq "Orderers" ]]) ; then
    fabric-ca-client enroll -u https://admin:kld89sJKdSFz@ca.scd.org.br:7054 --tls.certfiles /etc/hyperledger/fabric-ca-server-config/ca.scd.org.br-cert.pem
    fabric-ca-client register --id.name $user.scd.org.br --csr.hosts "$user.scd.org.br,scd.org.br" --id.secret $password --id.type peer -u https://admin:kld89sJKdSFz@ca.scd.org.br:7054 --tls.certfiles /etc/hyperledger/fabric-ca-server-config/ca.scd.org.br-cert.pem
    fabric-ca-client enroll -u https://$user.scd.org.br:$password@ca.scd.org.br:7054 -M $DIR/tmp/$type/$user --tls.certfiles /etc/hyperledger/fabric-ca-server-config/ca.scd.org.br-cert.pem
    fabric-ca-client enroll -d  --enrollment.profile tls --csr.hosts "$user.scd.org.br,scd.org.br" -u https://$user.scd.org.br:$password@ca.scd.org.br:7054 -M $DIR/tmp/$type/$user/tls --tls.certfiles /etc/hyperledger/fabric-ca-server-config/ca.scd.org.br-cert.pem

    #MSP
    if [[ ! -d "$DIR/$type" ]]; then
        mkdir $DIR/$type
    fi
    if [[ ! -d "$DIR/$type/$user.scd.org.br" ]]; then
        mkdir $DIR/$type/$user.scd.org.br
    fi
    mkdir $DIR/$type/$user.scd.org.br/msp
    mkdir $DIR/$type/$user.scd.org.br/tls
    cp -R $DIR/tmp/$type/$user/cacerts/ $DIR/$type/$user.scd.org.br/msp/
    cp -R $DIR/tmp/$type/$user/signcerts/ $DIR/$type/$user.scd.org.br/msp/
    cp -R $DIR/tmp/$type/$user/keystore/ $DIR/$type/$user.scd.org.br/msp/
    mv $DIR/$type/$user.scd.org.br/msp/signcerts/cert.pem $DIR/$type/$user.scd.org.br/msp/signcerts/$user.scd.org.br-cert.pem
    mv $DIR/$type/$user.scd.org.br/msp/cacerts/ca*.pem  $DIR/$type/$user.scd.org.br/msp/cacerts/ca.scd.org.br.pem
    mkdir $DIR/$type/$user.scd.org.br/msp/admincerts
    mkdir $DIR/$type/$user.scd.org.br/msp/tlscacerts
    cp $DIR/tmp/$type/$user/signcerts/cert.pem $DIR/$type/$user.scd.org.br/msp/admincerts/$user.scd.org.br-cert.pem

    #TLS
    cp -R $DIR/tmp/$type/$user/tls/signcerts/cert.pem $DIR/$type/$user.scd.org.br/tls/server.crt
    cp -R $DIR/tmp/$type/$user/tls/keystore/* $DIR/$type/$user.scd.org.br/tls/server.key
    cp -R $DIR/tmp/$type/$user/tls/tlscacerts/* $DIR/$type/$user.scd.org.br/tls/ca.crt
    cp -R $DIR/tmp/$type/$user/tls/tlscacerts/* $DIR/$type/$user.scd.org.br/msp/tlscacerts/tlsca.scd.org.br-cert.pem

    if [[ "$type" == "Peers" ]]; then
        echo "Replicate TLS to Users"
        cp -R $DIR/tmp/$type/$user/tls/tlscacerts/* $DIR/users/*/msp/tlscacerts
    fi
else
    echo "$DIR/$type/$user.scd.org.br already exist or is not a valid type"
fi
