cp /etc/resolv.conf /tmp/resolv.conf
cp /etc/hosts /tmp/hosts

echo "127.0.0.1   ca.scd.org.br" > /etc/hosts
echo "" > /etc/resolv.conf

cd /etc/hyperledger/fabric-ca-server-config

DIR=`pwd`

./generateUser.sh Admin admin123
./generateNodes.sh orderer 1 orderer123
./generateNodes.sh orderer 2 orderer123
./generateNodes.sh orderer 3 orderer123
./generateNodes.sh peer 1 orderer123
./generateNodes.sh peer 2 orderer123

mkdir $DIR/Peers/msp
cp -R $DIR/Peers/peer1.scd.org.br/msp/admincerts/ $DIR/Peers/msp/
cp -R $DIR/Peers/peer1.scd.org.br/msp/cacerts/ $DIR/Peers/msp/
cp -R $DIR/Peers/peer1.scd.org.br/msp/tlscacerts/ $DIR/Peers/msp/
echo "Saved on $DIR/Peers/msp/"

mkdir $DIR/Orderers/msp
cp -R $DIR/Orderers/orderer1.scd.org.br/msp/admincerts/ $DIR/Orderers/msp/
cp -R $DIR/Orderers/orderer1.scd.org.br/msp/cacerts/ $DIR/Orderers/msp/
cp -R $DIR/Orderers/orderer1.scd.org.br/msp/tlscacerts/ $DIR/Orderers/msp/
echo "Saved on $DIR/Orderers/msp/"

echo "NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/ca.scd.org.br-cert.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/scd.org.br-cert.pem
    OrganizationalUnitIdentifier: peer" >> $DIR/Peers/msp/config.yaml
cp $DIR/Peers/msp/config.yaml $DIR/Peers/*/msp/
