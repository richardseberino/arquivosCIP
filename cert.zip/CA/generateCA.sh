# PHYS_DIR=`pwd -P`
basedir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

rm -rf $basedir/files
mkdir $basedir/files

# generate some useful aliases
# fabricCaCertpfx=$basedir/fabricCaCertificate.pfx
confFile=$basedir/files/caconf
cakeyFile=$basedir/keyfile
cacertFile=$basedir/ca.scd.org.br-cert.pem
curveParamFile=$basedir/files/secp256k1.pem
serialFile=$basedir/files/serial
dbFile=$basedir/files/db


PAIS='BR'
ESTADO=' '
LOCALIDADE=' '

cat <<- EOF > $confFile
[ ca ]
default_ca = CA_default

[ CA_default ]
dir               = $basedir
certs             = $basedir/
crl_dir           = $basedir/
new_certs_dir     = $basedir/
database          = $dbFile
serial            = $basedir/files/serial
RANDFILE          = $basedir/
private_key       = $cakeyFile
certificate       = $cacertFile
crlnumber         = $basedir/files/number
crl               = $basedir/
crl_extensions    = crl_ext
default_crl_days  = 30
default_md        = sha256
name_opt          = ca_default
cert_opt          = ca_default
default_days      = 375
preserve          = no
policy            = policy_strict

[ policy_strict ]
organizationName        = match
organizationalUnitName  = optional
commonName              = supplied
emailAddress            = optional

[ v3_ca ]
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:true
keyUsage = critical, digitalSignature, keyEncipherment, cRLSign, keyCertSign
extendedKeyUsage = clientAuth, serverAuth

[ v3_tlsca ]
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:true
keyUsage = critical, digitalSignature, cRLSign, keyCertSign
extendedKeyUsage = clientAuth, emailProtection, serverAuth

[ usr_cert ]
basicConstraints=CA:FALSE
nsCertType                      = client, server, email
keyUsage                        = nonRepudiation, digitalSignature, keyEncipherment
extendedKeyUsage                = serverAuth, clientAuth, codeSigning, emailProtection
nsComment                       = "OpenSSL Generated Certificate"
subjectKeyIdentifier            = hash
authorityKeyIdentifier          = keyid,issuer

[ req ]
default_bits        = 2048
distinguished_name  = req_distinguished_name
string_mask         = utf8only
default_md          = sha256
x509_extensions     = v3_ca
req_extensions      = v3_req
x509_extensions     = usr_cert

[ v3_req]
extendedKeyUsage = serverAuth, clientAuth, codeSigning, emailProtection
basicConstraints = CA:FALSE
keyUsage = nonRepudiation, digitalSignature, keyEncipherment

[ req_distinguished_name ]
countryName        = $PAIS
stateOrProvidenceName        = $ESTADO
localityName       = $LOCALIDADE
organizationName        = ca.scd.org.br
commonName        = ca.scd.org.br
EOF

# create the file with the serial numbers
echo 01 > $serialFile

# create an empty DB file
touch $dbFile

# generate ctoucha private key
openssl ecparam -name prime256v1 -out $curveParamFile
openssl ecparam -in $curveParamFile -genkey -noout -out $cakeyFile

# generate ca cert
openssl req -config $confFile -key $cakeyFile -new -x509 -days 365 -sha256 -extensions v3_ca -out $cacertFile -subj "/C=$PAIS/ST=$ESTADO/L=$LOCALIDADE/O=ca.scd.org.br/CN=ca.scd.org.br"

chmod 400 $cacertFile
chmod 400 $cakeyFile
