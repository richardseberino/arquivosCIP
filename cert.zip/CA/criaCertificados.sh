cp /etc/resolv.conf /tmp/resolv.conf
cp /etc/hosts /tmp/hosts

echo "127.0.0.1   ca.scd.org.br" > /etc/hosts
echo "" > /etc/resolv.conf

export CATLS='/etc/hyperledger/fabric-ca-server-config/ca.scd.org.br-cert.pem'
export CAURL='ca.scd.org.br:7054'
export DIRPAI='/etc/hyperledger/fabric-ca-server-config/enrollments'

cd /etc/hyperledger/fabric-ca-server-config/

echo "Limpando diretorio de certificado de instalações anteriores"
rm -Rf Peer/msp
rm -Rf Peer/Peer1/peer/
rm -Rf Peer/Peer1/msp/
rm -Rf Peer/Peer2/peer/
rm -Rf Peer/Peer2/msp/
rm -Rf Orderer
mkdir Orderer/

echo "Criando usuarios e certificados - Admin"
fabric-ca-client enroll -u https://admin:kld89sJKdSFz@$CAURL --tls.certfiles $CATLS
fabric-ca-client register --id.name Admin@scd.org.br --id.attrs 'hf.Revoker=true,admin=true:ecert' --id.secret admin123 --id.type client -u https://admin:kld89sJKdSFz@$CAURL --tls.certfiles $CATLS
fabric-ca-client enroll -u https://Admin@scd.org.br:admin123@$CAURL -M $DIRPAI/admin --tls.certfiles $CATLS
fabric-ca-client enroll -d --enrollment.profile tls --csr.hosts 'peer1.scd.org.br,peer2.scd.org.br,scd.org.br,peer1,peer2' -u https://Admin@scd.org.br:admin123@ca.scd.org.br:7054 -M $DIRPAI/admin/tls --tls.certfiles $CATLS

echo "Criando usuarios e certificados - Peer1"
fabric-ca-client register --id.name peer1@scd.org.br --id.secret peer123 --id.type peer --csr.hosts 'peer1.scd.org.br,scd.org.br,peer1' -u https://admin:kld89sJKdSFz@$CAURL --tls.certfiles $CATLS
fabric-ca-client enroll -u https://peer1@scd.org.br:peer123@ca.scd.org.br:7054 -M $DIRPAI/peer1 --tls.certfiles $CATLS
fabric-ca-client enroll -d --enrollment.profile tls --csr.hosts 'peer1.scd.org.br,scd.org.br,peer1' -u https://peer1@scd.org.br:peer123@ca.scd.org.br:7054 -M $DIRPAI/peer1/tls --tls.certfiles $CATLS

echo "Criando usuarios e certificados - Peer2"
fabric-ca-client register --id.name peer2@scd.org.br --id.secret peer123 --id.type peer --csr.hosts 'peer2.scd.org.br,scd.org.br,peer2' -u https://admin:kld89sJKdSFz@$CAURL --tls.certfiles $CATLS
fabric-ca-client enroll -u https://peer2@scd.org.br:peer123@ca.scd.org.br:7054 -M $DIRPAI/peer2 --tls.certfiles $CATLS
fabric-ca-client enroll -d --enrollment.profile tls --csr.hosts 'peer2.scd.org.br,scd.org.br,peer2' -u https://peer2@scd.org.br:peer123@ca.scd.org.br:7054 -M $DIRPAI/peer2/tls --tls.certfiles $CATLS

echo "Criando usuarios e certificados - Orderer1"
fabric-ca-client register --id.name orderer1@scd.org.br --id.secret orderer123 --id.type peer --csr.hosts 'orderer1.scd.org.br,scd.org.br,orderer1,orderer-svc,orderer.scd.org.br' -u https://admin:kld89sJKdSFz@$CAURL --tls.certfiles $CATLS
fabric-ca-client enroll -u https://orderer1@scd.org.br:orderer123@ca.scd.org.br:7054 -M $DIRPAI/orderer1 --tls.certfiles $CATLS
fabric-ca-client enroll -d --enrollment.profile tls --csr.hosts 'orderer1.scd.org.br,scd.org.br,orderer1,orderer.scd.org.br,orderer-svc' -u https://orderer1@scd.org.br:orderer123@ca.scd.org.br:7054 -M $DIRPAI/orderer1/tls --tls.certfiles $CATLS

echo "Criando usuarios e certificados - Orderer2"
fabric-ca-client register --id.name orderer2@scd.org.br --id.secret orderer123 --id.type peer --csr.hosts 'orderer2.scd.org.br,scd.org.br,orderer2,orderer-svc,orderer.scd.org.br' -u https://admin:kld89sJKdSFz@$CAURL --tls.certfiles $CATLS
fabric-ca-client enroll -u https://orderer2@scd.org.br:orderer123@ca.scd.org.br:7054 -M $DIRPAI/orderer2 --tls.certfiles $CATLS
fabric-ca-client enroll --enrollment.profile tls --csr.hosts 'orderer2.scd.org.br,scd.org.br,orderer2,orderer.scd.org.br,orderer-svc' -u https://orderer2@scd.org.br:orderer123@ca.scd.org.br:7054 -M $DIRPAI/orderer2/tls --tls.certfiles $CATLS

echo "Criando usuarios e certificados - Orderer3"
fabric-ca-client register --id.name orderer3@scd.org.br --id.secret orderer123 --id.type peer --csr.hosts 'orderer3.scd.org.br,scd.org.br,orderer3,orderer-svc,orderer.scd.org.br' -u https://admin:kld89sJKdSFz@$CAURL --tls.certfiles $CATLS
fabric-ca-client enroll -u https://orderer3@scd.org.br:orderer123@ca.scd.org.br:7054 -M $DIRPAI/orderer3 --tls.certfiles $CATLS
fabric-ca-client enroll -d --enrollment.profile tls --csr.hosts 'orderer3.scd.org.br,scd.org.br,orderer3,orderer.scd.org.br,orderer-svc' -u https://orderer3@scd.org.br:orderer123@ca.scd.org.br:7054 -M $DIRPAI/orderer3/tls --tls.certfiles $CATLS


echo "Configurando usuario administrativo"
mkdir Admin@scd.org.br
mkdir Admin@scd.org.br/msp
mkdir Admin@scd.org.br/tls
cp -R $DIRPAI/admin/cacerts/ Admin@scd.org.br/msp/
cp -R $DIRPAI/admin/signcerts/ Admin@scd.org.br/msp/
cp -R $DIRPAI/admin/keystore/ Admin@scd.org.br/msp/
cp $DIRPAI/admin/tls/keystore/*_sk Admin@scd.org.br/tls/client.key
cp $DIRPAI/admin/tls/signcerts/cert.pem Admin@scd.org.br/tls/client.crt
cp $DIRPAI/admin/tls/tlscacerts/*.pem Admin@scd.org.br/tls/ca.crt
mv Admin@scd.org.br/msp/signcerts/cert.pem Admin@scd.org.br/msp/signcerts/Admin@scd.org.br-cert.pem
mv Admin@scd.org.br/msp/cacerts/*.pem Admin@scd.org.br/msp/cacerts/ca.scd.org.br-cert.pem
mkdir Admin@scd.org.br/msp/admincerts
mkdir Admin@scd.org.br/msp/tlscacerts
cp $DIRPAI/admin/signcerts/cert.pem Admin@scd.org.br/msp/admincerts/Admin@scd.org.br-cert.pem
cp $DIRPAI/admin/tls/tlscacerts/*.pem Admin@scd.org.br/msp/tlscacerts/tlsca.scd.org.br-cert.pem

echo "Preparando Peer 1"
mkdir peer1@scd.org.br
mkdir peer1@scd.org.br/msp
mkdir peer1@scd.org.br/tls
cp -R $DIRPAI/peer1/cacerts/ peer1@scd.org.br/msp/
cp -R $DIRPAI/peer1/signcerts/ peer1@scd.org.br/msp/
cp -R $DIRPAI/peer1/keystore/ peer1@scd.org.br/msp/
cp -R $DIRPAI/peer1/tls/keystore/*_sk peer1@scd.org.br/tls/server.key
cp -R $DIRPAI/peer1/tls/signcerts/cert.pem peer1@scd.org.br/tls/server.crt
cp -R $DIRPAI/peer1/tls/tlscacerts/*.pem peer1@scd.org.br/tls/ca.crt
mv peer1@scd.org.br/msp/signcerts/cert.pem peer1@scd.org.br/msp/signcerts/peer1.scd.org.br-cert.pem
mv peer1@scd.org.br/msp/cacerts/*.pem peer1@scd.org.br/msp/cacerts/ca.scd.org.br-cert.pem
mkdir peer1@scd.org.br/msp/admincerts
mkdir peer1@scd.org.br/msp/tlscacerts
cp $DIRPAI/admin/signcerts/cert.pem peer1@scd.org.br/msp/admincerts/Admin@scd.org.br-cert.pem
cp -R $DIRPAI/peer1/tls/tlscacerts/*.pem peer1@scd.org.br/msp/tlscacerts/tlsca.scd.org.br-cert.pem

echo "NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/ca.scd.org.br-cert.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/ca.scd.org.br-cert.pem
    OrganizationalUnitIdentifier: peer" >> peer1@scd.org.br/msp/config.yaml

mkdir Peer/Peer1/msp/
mkdir Peer/Peer1/msp/users
mkdir Peer/Peer1/msp/orderer

cp -R peer1@scd.org.br/msp Peer/Peer1/
cp -R peer1@scd.org.br/tls Peer/Peer1/
cp -R Admin@scd.org.br Peer/Peer1/msp/users/
cp -R peer1@scd.org.br Peer/Peer1/msp/users/

echo "Preparando Peer 2"
mkdir peer2@scd.org.br
mkdir peer2@scd.org.br/msp
mkdir peer2@scd.org.br/tls
cp -R $DIRPAI/peer2/cacerts/ peer2@scd.org.br/msp/
cp -R $DIRPAI/peer2/signcerts/ peer2@scd.org.br/msp/
cp -R $DIRPAI/peer2/keystore/ peer2@scd.org.br/msp/
cp -R $DIRPAI/peer2/tls/keystore/*_sk peer2@scd.org.br/tls/server.key
cp -R $DIRPAI/peer2/tls/signcerts/cert.pem peer2@scd.org.br/tls/server.crt
cp -R $DIRPAI/peer2/tls/tlscacerts/*.pem peer2@scd.org.br/tls/ca.crt
mv peer2@scd.org.br/msp/signcerts/cert.pem peer2@scd.org.br/msp/signcerts/peer2.scd.org.br-cert.pem
mv peer2@scd.org.br/msp/cacerts/*.pem peer2@scd.org.br/msp/cacerts/ca.scd.org.br-cert.pem
mkdir peer2@scd.org.br/msp/admincerts
mkdir peer2@scd.org.br/msp/tlscacerts
cp $DIRPAI/admin/signcerts/cert.pem peer2@scd.org.br/msp/admincerts/Admin@scd.org.br-cert.pem
cp -R $DIRPAI/peer2/tls/tlscacerts/*.pem peer2@scd.org.br/msp/tlscacerts/tlsca.scd.org.br-cert.pem

echo "NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/ca.scd.org.br-cert.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/ca.scd.org.br-cert.pem
    OrganizationalUnitIdentifier: peer" >> peer2@scd.org.br/msp/config.yaml

mkdir Peer/Peer2/msp/
mkdir Peer/Peer2/msp/users
mkdir Peer/Peer2/msp/orderer

cp -R peer2@scd.org.br/msp Peer/Peer2/
cp -R peer2@scd.org.br/tls Peer/Peer2/
cp -R Admin@scd.org.br Peer/Peer2/msp/users/
cp -R peer2@scd.org.br Peer/Peer2/msp/users/

echo "Preparando MSP dos Peers"
mkdir Peer/msp
mkdir Peer/msp/cacerts
cp -R peer2@scd.org.br/msp/tlscacerts Peer/msp/
cp peer2@scd.org.br/msp/config.yaml Peer/msp
cp ca.scd.org.br-cert.pem Peer/msp/cacerts
cp -R Admin@scd.org.br/msp/admincerts Peer/msp/

echo "Preparando Orderer1"
mkdir orderer1@scd.org.br
mkdir orderer1@scd.org.br/msp
mkdir orderer1@scd.org.br/tls
cp -R $DIRPAI/orderer1/cacerts/ orderer1@scd.org.br/msp/
cp -R $DIRPAI/orderer1/signcerts/ orderer1@scd.org.br/msp/
cp -R $DIRPAI/orderer1/keystore/ orderer1@scd.org.br/msp/
cp -R $DIRPAI/orderer1/tls/keystore/*_sk orderer1@scd.org.br/tls/server.key
cp -R $DIRPAI/orderer1/tls/signcerts/cert.pem orderer1@scd.org.br/tls/server.crt
cp -R $DIRPAI/orderer1/tls/tlscacerts/*.pem orderer1@scd.org.br/tls/ca.crt
mv orderer1@scd.org.br/msp/signcerts/cert.pem orderer1@scd.org.br/msp/signcerts/orderer1.scd.org.br-cert.pem
mv orderer1@scd.org.br/msp/cacerts/*.pem orderer1@scd.org.br/msp/cacerts/ca.scd.org.br-cert.pem
mkdir orderer1@scd.org.br/msp/admincerts
mkdir orderer1@scd.org.br/msp/tlscacerts
cp $DIRPAI/admin/signcerts/cert.pem orderer1@scd.org.br/msp/admincerts/Admin@scd.org.br-cert.pem
cp -R $DIRPAI/orderer1/tls/tlscacerts/*.pem  orderer1@scd.org.br/msp/tlscacerts/tlsca.scd.org.br-cert.pem
mkdir Orderer/Orderer1
cp -R orderer1@scd.org.br/msp Orderer/Orderer1/
cp -R orderer1@scd.org.br/tls Orderer/Orderer1/

echo "Preparando Orderer2"
mkdir orderer2@scd.org.br
mkdir orderer2@scd.org.br/msp
mkdir orderer2@scd.org.br/tls
cp -R $DIRPAI/orderer2/cacerts/ orderer2@scd.org.br/msp/
cp -R $DIRPAI/orderer2/signcerts/ orderer2@scd.org.br/msp/
cp -R $DIRPAI/orderer2/keystore/ orderer2@scd.org.br/msp/
cp -R $DIRPAI/orderer2/tls/keystore/*_sk orderer2@scd.org.br/tls/server.key
cp -R $DIRPAI/orderer2/tls/signcerts/cert.pem orderer2@scd.org.br/tls/server.crt
cp -R $DIRPAI/orderer2/tls/tlscacerts/*.pem orderer2@scd.org.br/tls/ca.crt
mv orderer2@scd.org.br/msp/signcerts/cert.pem orderer2@scd.org.br/msp/signcerts/orderer2.scd.org.br-cert.pem
mv orderer2@scd.org.br/msp/cacerts/*.pem orderer2@scd.org.br/msp/cacerts/ca.scd.org.br-cert.pem
mkdir orderer2@scd.org.br/msp/admincerts
mkdir orderer2@scd.org.br/msp/tlscacerts
cp $DIRPAI/admin/signcerts/cert.pem orderer2@scd.org.br/msp/admincerts/Admin@scd.org.br-cert.pem
cp -R $DIRPAI/orderer2/tls/tlscacerts/*.pem orderer2@scd.org.br/msp/tlscacerts/tlsca.scd.org.br-cert.pem
mkdir Orderer/Orderer2
cp -R orderer2@scd.org.br/msp Orderer/Orderer2/
cp -R orderer2@scd.org.br/tls Orderer/Orderer2/

echo "Preparando orderer3"
mkdir orderer3@scd.org.br
mkdir orderer3@scd.org.br/msp
mkdir orderer3@scd.org.br/tls
cp -R $DIRPAI/orderer3/cacerts/ orderer3@scd.org.br/msp/
cp -R $DIRPAI/orderer3/signcerts/ orderer3@scd.org.br/msp/
cp -R $DIRPAI/orderer3/keystore/ orderer3@scd.org.br/msp/
cp -R $DIRPAI/orderer3/tls/keystore/*_sk orderer3@scd.org.br/tls/server.key
cp -R $DIRPAI/orderer3/tls/signcerts/cert.pem orderer3@scd.org.br/tls/server.crt
cp -R $DIRPAI/orderer3/tls/tlscacerts/*.pem orderer3@scd.org.br/tls/ca.crt
mv orderer3@scd.org.br/msp/signcerts/cert.pem orderer3@scd.org.br/msp/signcerts/orderer3.scd.org.br-cert.pem
mv orderer3@scd.org.br/msp/cacerts/*.pem orderer3@scd.org.br/msp/cacerts/ca.scd.org.br-cert.pem
mkdir orderer3@scd.org.br/msp/admincerts
mkdir orderer3@scd.org.br/msp/tlscacerts
cp $DIRPAI/admin/signcerts/cert.pem orderer3@scd.org.br/msp/admincerts/Admin@scd.org.br-cert.pem
cp -R $DIRPAI/orderer3/tls/tlscacerts/*.pem orderer3@scd.org.br/msp/tlscacerts/tlsca.scd.org.br-cert.pem
mkdir Orderer/Orderer3
cp -R orderer3@scd.org.br/msp Orderer/Orderer3/
cp -R orderer3@scd.org.br/tls Orderer/Orderer3/

cp -R orderer1@scd.org.br/msp Peer/Peer1/msp/orderer
cp -R orderer2@scd.org.br/msp Peer/Peer2/msp/orderer


echo "Preparando MSP dos Orderer"
mkdir Orderer/msp
mkdir Orderer/msp/cacerts
cp ca.scd.org.br-cert.pem Orderer/msp/cacerts
cp -R Admin@scd.org.br/msp/admincerts Orderer/msp
cp -R orderer1@scd.org.br/msp/tlscacerts Orderer/msp

cat /tmp/resolv.conf > /etc/resolv.conf
cat /tmp/hosts > /etc/hosts

rm -Rf /tmp/resolv.conf
rm -Rf /tmp/hosts
