#!/usr/bin/env bash

user=$1
password=$2
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

if [[ ! -d "$DIR/users/$user@scd.org.br/msp" ]] && [[ ! -d "$DIR/$type/$user@scd.org.br/tls" ]]; then

    fabric-ca-client enroll -u https://admin:kld89sJKdSFz@ca.scd.org.br:7054 --tls.certfiles /etc/hyperledger/fabric-ca-server-config/ca.scd.org.br-cert.pem
    fabric-ca-client register --id.name $user@scd.org.br --id.secret $password --id.type client -u https://admin:kld89sJKdSFz@ca.scd.org.br:7054 --tls.certfiles /etc/hyperledger/fabric-ca-server-config/ca.scd.org.br-cert.pem
    fabric-ca-client enroll -u https://$user@scd.org.br:admin123@ca.scd.org.br:7054 -M $DIR/tmp/users/$user --tls.certfiles /etc/hyperledger/fabric-ca-server-config/ca.scd.org.br-cert.pem

    if [[ ! -d "$DIR/users" ]]; then
        mkdir $DIR/users
    fi

    if [[ ! -d "$DIR/users/$user.scd.org.br" ]]; then
        mkdir $DIR/users/$user@scd.org.br
    fi
    mkdir $DIR/users/$user@scd.org.br/msp
    cp -R $DIR/tmp/users/$user/cacerts/ $DIR/users/$user@scd.org.br/msp/
    cp -R $DIR/tmp/users/$user/signcerts/ $DIR/users/$user@scd.org.br/msp/
    cp -R $DIR/tmp/users/$user/keystore/ $DIR/users/$user@scd.org.br/msp/
    mv $DIR/users/$user@scd.org.br/msp/signcerts/cert.pem $DIR/users/$user@scd.org.br/msp/signcerts/$user@scd.org.br-cert.pem
    mv $DIR/users/$user@scd.org.br/msp/cacerts/ca*.pem  $DIR/users/$user@scd.org.br/msp/cacerts/ca.scd.org.br.pem
    mkdir $DIR/users/$user@scd.org.br/msp/admincerts
    mkdir $DIR/users/$user@scd.org.br/msp/tlscacerts
    cp $DIR/tmp/users/$user/signcerts/cert.pem $DIR/users/$user@scd.org.br/msp/admincerts/$user@scd.org.br-cert.pem
    cp ./ca.scd.org.br-cert.pem $DIR/users/$user@scd.org.br/msp/tlscacerts/tlsca.scd.org.br.pem

else
    echo "$DIR/users/$user@scd.org.br already exist"
fi
