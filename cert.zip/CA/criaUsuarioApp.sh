cp /etc/resolv.conf /tmp/resolv.conf
cp /etc/hosts /tmp/hosts

echo "127.0.0.1   ca.scd.org.br" > /etc/hosts
echo "" > /etc/resolv.conf
fabric-ca-client enroll -u https://admin:kld89sJKdSFz@ca.scd.org.br:7054 --tls.certfiles /etc/hyperledger/fabric-ca-server-config/ca.scd.org.br-cert.pem

fabric-ca-client register  --id.name deviceid --id.type client --id.secret device123 -u https://admin:adminpw@ca.scd.org.br:7054 --tls.certfiles /etc/hyperledger/fabric-ca-server-config/ca.scd.org.br-cert.pem
rm -Rf /etc/hyperledger/fabric-ca-server/msp

fabric-ca-client enroll -u https://deviceid:device123@ca.scd.org.br:7054 --tls.certfiles /etc/hyperledger/fabric-ca-server-config/ca.scd.org.br-cert.pem
cp /etc/hyperledger/fabric-ca-server/msp/keystore/*_sk /etc/hyperledger/fabric-ca-server-config/deviceid_priv
cp /etc/hyperledger/fabric-ca-server/msp/signcerts/cert.pem  /etc/hyperledger/fabric-ca-server-config/deviceid.pem


cat /tmp/resolv.conf > /etc/resolv.conf
cat /tmp/hosts > /etc/hosts

rm -Rf /tmp/resolv.conf
rm -Rf /tmp/hosts
